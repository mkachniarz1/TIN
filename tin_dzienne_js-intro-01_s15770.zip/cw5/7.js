// Typ parametru

function type(param){
    console.log(typeof(param));
    return typeof(param);
}

type(12);
type("12");
type(type());